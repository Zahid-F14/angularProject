﻿using AngularProject.Factories;
using AngularProject.Interfaces;
using AngularProject.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AngularProject.api
{
    [RoutePrefix("api")]
    public class apiItemController : ApiController
    {
        private iItemUnit objUnit = null;

        public apiItemController()
        {
            objUnit = new fItemUnit();

        }
        [HttpPost]

        public HttpResponseMessage temp(object[] data)
        {
            string result = "";
            DbTable cmnparam = JsonConvert.DeserializeObject<DbTable>(data[0].ToString());
            if (cmnparam != null)
            {
                result = objUnit.saveItem(cmnparam);
            }
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }


        [HttpGet]
        public List<DbTable> GetAllData()
        {
            List<DbTable> lst = new List<DbTable>();
            lst = objUnit.getItem();
            return lst;
        }

    }
}