﻿var ItemApp = angular.module('angularApp', []);
ItemApp.controller('validateController', ['$scope', 'crudService', function ($scope, crudService) {

    $scope.CsGroup = "";
    $scope.Code = "";
    $scope.Name = "";
    $scope.Qty = "";
    $scope.Price = "";
    

    $scope.submitItemForm = function () {
        var apiRoute = '/api/apItem/temp/';
        var data = {
            Code: $scope.Code,
            Name: $scope.Name,
            Qty: $scope.Qty,
            Price: $scope.Price,
            Csgroup: $scope.CsGroup
        }
        //console.log(data, data.Csgroup, data.Name);
        var cmnParam = '[' + JSON.stringify(data) + ']';
        var create = crudService.GetList(apiRoute, cmnParam);

        create.then(function (response) {
            alert(JSON.stringify(response));
           

        },
      function (error) {
          console.log("error: " + error);
      }
      );
    }



    $scope.showList = function () {

        $scope.gridOptions = {

            paginationPageSizes: [25, 50, 75],

            paginationPageSize: 5,

            columnDefs: [

            { field: 'CsGroup' },

            { field: 'Code' },

            { field: 'Name' },

            { field: 'Qty' },

            { field: 'Price' },

             {
                 name: 'Action',
                 displayName: "Action",

                 enableColumnResizing: false,
                 enableFiltering: false,
                 enableSorting: false,
                 pinnedRight: true,


                 width: '15%',
                 headerCellClass: $scope.highlightFilteredHeader,
                 cellTemplate: '<span class="label label-info label-mini" style="text-align:center !important;">' +
                               '<a href="" title="Edit" ng-click="grid.appScope.Edit(row.entity)">' +
                                 '<i class="icon-edit" aria-hidden="true"></i> Edit' +
                               '</a>' +
                               '</span>' +

                               '<span class="label label-danger label-mini" style="text-align:center !important;">' +
                               '<a href="" title="Delete" ng-click="grid.appScope.delete(row.entity)">' +
                                 '<i class="icon-glyphicon glyphicon-trash" aria-hidden="true"></i> Delete' +
                               '</a>' +
                               '</span>'

             }


            ],

            onRegisterApi: function (gridApi) {

                $scope.grid1Api = gridApi;

            }

        };

        var apiRoute = '/api/apItem/GetAllData/';
        var receiveData = crudService.ShowData(apiRoute);
        receiveData.then(function (response) {
            console.log(response);
            $scope.gridOptions.data = response.data;
        },
         function (error) {
             console.log("error: " + error);
         }
        );



    } ;

    var receiveData;

    
    $scope.Edit = function (data) {
        alert(JSON.stringify(data));

        $scope.CsGroup = data.CsGroup;
        $scope.Code = data.Code;
        $scope.Name = data.Name;
        $scope.Qty = data.Qty;
        $scope.Price = data.Price;

    }




    }
    ]);