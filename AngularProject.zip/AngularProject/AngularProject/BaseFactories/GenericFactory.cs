﻿using AngularProject.BaseInterfaces;
using AngularProject.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AngularProject.BaseFactories
{
    public class GenericFactory<C,T>: iGenericFactory<T>
        where C : angularDBEntities1, new()
        where T:class
    {
        private C _dbctx = new C();
        protected C Context
        {
            get
            {
                return _dbctx;
            }
            set
            {
                _dbctx = value;
            }
        }
        public virtual string ExecuteInsertCommand(string spQuery, Hashtable ht)
        {
            string result = "";
            bool temp = false;


            using (_dbctx.Database.Connection)
            {
                _dbctx.Database.Connection.Open();
                DbCommand cmd = _dbctx.Database.Connection.CreateCommand();
                cmd.CommandText = spQuery;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                foreach (object obj in ht)
                {
                    string str = Convert.ToString(obj);
                    SqlParameter param = new SqlParameter('@' + str, ht[obj]);
                    cmd.Parameters.Add(param);
                }
                cmd.ExecuteNonQuery();
                temp = true;

            }

            if (temp)
            {
                return result;
            }
            else
            {
                return "Operation failed!!!";
            }


        }



        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
                if (disposing)
                    _dbctx.Dispose();
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        List<DbTable> ExecuteShowCommand()
        {
                 
            List<DbTable>List = new List<DbTable>();
            using (_dbctx.Database.Connection)
            {

                _dbctx.Database.Connection.Open();
                DbCommand cmd = _dbctx.Database.Connection.CreateCommand();
                cmd.CommandText = "GetAll";
                cmd.CommandType= System.Data.CommandType.StoredProcedure;

                IDataReader dr = cmd.ExecuteReader();
                while(dr.Read())
                {
                    List.Add(new DbTable
                    {
                        Id=Convert.ToInt32(dr["Id"]),
                        CSGroup = dr["CSGroup"].ToString(),
                        Code = dr["Code"].ToString(),
                        Name = dr["Name"].ToString(),
                        Qty = Convert.ToInt32(dr["Qty"]),
                        Price = Convert.ToInt32(dr["Price"])
                    });
                }
            
            }
            return List;
        }
        }



    }
}