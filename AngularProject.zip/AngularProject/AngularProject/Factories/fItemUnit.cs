﻿using AngularProject.BaseFactories;
using AngularProject.BaseInterfaces;
using AngularProject.Interfaces;
using AngularProject.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web;

namespace AngularProject.Factories
{
    public class fItemUnit:iItemUnit
    {
        private iGenericFactory<DbTable> genericobj = null;
        public string saveItem(DbTable item){
            genericobj = new GenericFactory<angularDBEntities1, DbTable>();
            string spQuery = "";
            string result = "";
            Hashtable ht = new Hashtable();
            ht.Add("Csgroup", item.CSGroup);
            ht.Add("Code", item.Code);
            ht.Add("Name", item.Name);
            ht.Add("Qty", item.Qty);
            ht.Add("Price", item.Price);
            spQuery = "[Insert_data]";
            result = genericobj.ExecuteInsertCommand(spQuery, ht);
            return result;

        }
        List<DbTable> getItem()
        {
            genericobj = new GenericFactory<angularDBEntities1, DbTable>();
            List<DbTable> List = genericobj.ExecuteShowCommand();
            return List;
        }
    }
}