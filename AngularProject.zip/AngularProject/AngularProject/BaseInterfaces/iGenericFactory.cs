﻿using AngularProject.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AngularProject.BaseInterfaces
{
    interface iGenericFactory<T> :IDisposable where T: class
    {
        string ExecuteInsertCommand( string spQuery, Hashtable ht);
        List<DbTable> ExecuteShowCommand();
    }
}
