﻿using AngularProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AngularProject.Interfaces
{
    interface iItemUnit
    {
        string saveItem(DbTable item);
        List<DbTable> getItem();
    }
}
